﻿// Animation d'apparition au défilement (Scroll Reveal)
document.addEventListener("DOMContentLoaded", function () {
    const reveals = document.querySelectorAll(".reveal");

    // Options de l'observateur
    const observerOptions = {
        root: null,
        rootMargin: "0px",
        threshold: 0.15 // L'élément doit être visible à 15% pour déclencher l'animation
    };

    const observer = new IntersectionObserver(function (entries, observer) {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                // Ajoute la classe 'active' pour lancer l'animation CSS
                entry.target.classList.add("active");
                // On arrête d'observer cet élément une fois qu'il est visible
                observer.unobserve(entry.target);
            }
        });
    }, observerOptions);

    // On observe chaque élément avec la classe 'reveal'
    reveals.forEach(reveal => {
        observer.observe(reveal);
    });

    // Animation d'apparition immédiate pour les éléments déjà visibles au chargement (Hero section)
    setTimeout(() => {
        const heroElements = document.querySelectorAll(".hero .reveal");
        heroElements.forEach(el => el.classList.add("active"));
    }, 100);
});
